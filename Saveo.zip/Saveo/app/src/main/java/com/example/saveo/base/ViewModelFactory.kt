package com.example.saveo.base


import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.saveo.remote.ApiCallMethods
import com.example.saveo.ui.moviedetail.MovieDetailViewModel
import com.example.saveo.ui.movielist.MovieListViewActor
import com.example.saveo.ui.movielist.MovieListViewModel

/**
 * @AUTHOR Naimish Gupta
 * @date 05/01/2022
 * */

@Suppress("UNCHECKED_CAST")
class ViewModelFactory(
    private val apiCallMethods: ApiCallMethods

) : ViewModelProvider.NewInstanceFactory() {

    override fun <T : ViewModel> create(modelClass: Class<T>) =
        with(modelClass) {
            when {
                isAssignableFrom(MovieListViewModel::class.java) ->
                    MovieListViewModel(apiCallMethods)
                isAssignableFrom(MovieDetailViewModel::class.java)->
                    MovieDetailViewModel(apiCallMethods)
                else ->
                    throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
        } as T

}