package com.example.saveo.utility


/**
 * @AUTHOR Naimish Gupta
 * @date 05/01/2022
 */
fun Int.isAddLoading(totalCount: Int, perPage: Int = 20): Boolean {
    return this < kotlin.math.ceil(totalCount.toDouble() / perPage)//1<0.20
}