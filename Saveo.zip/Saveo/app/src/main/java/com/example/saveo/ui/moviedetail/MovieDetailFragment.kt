package com.example.saveo.ui.moviedetail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.saveo.R
import com.example.saveo.databinding.FragmentMovieDetailBinding
import com.example.saveo.ui.mainactivity.MainActivity
import com.example.saveo.utility.Constants
import com.example.saveo.utility.getViewModelFactory


class MovieDetailFragment : Fragment(), MovieDetailViewActor {

    //region variable
    private val mviewModel by viewModels<MovieDetailViewModel> { getViewModelFactory() }
    private var _binding: FragmentMovieDetailBinding? = null
    //endregion

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mviewModel.setViewActor(this) //setting viewActor
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        //dataBinding
        _binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_movie_detail, container, false)
        return _binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //region extract argument variable
        mviewModel.movieId = requireArguments()[Constants.KEY_MOVIE_ID] as Int
        //endregion
        mviewModel.getMovieDetails()
        observeData()
    }

    //region ViewActorMethod
    override fun onBackPressed() {
        (activity as MainActivity).onBackPressed()
    }
    //endregion

    fun observeData() {
        mviewModel.movieDetaiResponse.observe(viewLifecycleOwner, {
            _binding?.itemData = it  //binding data with itemdata
        })

    }



}