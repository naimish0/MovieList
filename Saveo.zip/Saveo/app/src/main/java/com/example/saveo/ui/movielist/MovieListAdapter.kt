package com.example.saveo.ui.movielist

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.recyclerview.widget.RecyclerView
import com.example.saveo.BR
import com.example.saveo.R
import com.example.saveo.data.response.MovieListResponse


/**
 * @AUTHOR Naimish Gupta
 * @date 05/01/2022
 */
class MovieListAdapter(val viewModel: MovieListViewModel):RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    //region variable
    private val mDataList = mutableListOf<MovieListResponse.Result>()
    private var lastPosition = -1
    //endregion

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val binding: ViewDataBinding = DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.row_item_movie_list,
                parent,
                false
            )
            return ViewHolder(binding, viewModel)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is MovieListAdapter.ViewHolder)
            holder.bindData(mDataList[position])
    }
    fun updateList(list: List<MovieListResponse.Result>) {
        mDataList.clear()
        mDataList.addAll(list)
        notifyDataSetChanged()
    }
    fun addLoading() {
        mDataList.add(MovieListResponse.Result())
        notifyItemInserted(mDataList.size - 1)
    }
    override fun getItemCount(): Int {
        return mDataList.size
    }
    inner class ViewHolder(
        val binding: ViewDataBinding,
        val mViewModel: MovieListViewModel
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bindData(itemData: MovieListResponse.Result) {  //setting data binding variables
            binding.setVariable(BR.viewModel,mViewModel)
            binding.setVariable(BR.adapterPosition,adapterPosition)
            binding.setVariable(BR.itemData, itemData)
            binding.executePendingBindings()
        }
    }
}