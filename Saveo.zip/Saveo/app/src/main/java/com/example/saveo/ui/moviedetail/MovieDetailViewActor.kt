package com.example.saveo.ui.moviedetail

interface MovieDetailViewActor {

    /**
     * onBackArrow Click Method
     */
    fun onBackPressed()
}