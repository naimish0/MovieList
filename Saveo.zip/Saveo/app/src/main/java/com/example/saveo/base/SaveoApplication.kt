package com.example.saveo.base

import android.app.Application
import com.example.saveo.remote.ApiCallMethods
import com.example.saveo.remote.ApiHandler

/**
 * @AUTHOR Naimish Gupta
 * @date 05/01/2022
 */
class SaveoApplication : Application() {
    //region Companion Object
    companion object {
        private var app: SaveoApplication? = null
        val apiCallMethods: ApiCallMethods get() = ApiHandler.getInstance().handler

    }

    override fun onCreate() {
        super.onCreate()
        app = this
    }
}