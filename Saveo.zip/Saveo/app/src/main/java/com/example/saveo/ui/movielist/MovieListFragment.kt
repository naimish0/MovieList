package com.example.saveo.ui.movielist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.saveo.R
import com.example.saveo.data.response.MovieListResponse
import com.example.saveo.databinding.FragmentMovieListBinding
import com.example.saveo.ui.moviedetail.MovieDetailFragment
import com.example.saveo.utility.*


/**
 * @AUTHOR Naimish Gupta
 * @date 05/01/2022
 */
class MovieListFragment : Fragment(), MovieListViewActor {

    //region variables
    private var _binding: FragmentMovieListBinding? = null
    private val mviewModel by viewModels<MovieListViewModel> { getViewModelFactory() }
    private val mAdapter by lazy { MovieListAdapter(mviewModel) }
    private lateinit var mPaginationHandler: PaginationHandler
    private val mMovieList = mutableListOf<MovieListResponse.Result>()
    private var mCountTotal = 0
    private var mPage: Int = 1
    private lateinit var mPaginationHandlerMulti: PaginationHandlerMulti

    //endregion

    // region lifecycle methods
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mviewModel.setViewActor(this)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DataBindingUtil.inflate(inflater, R.layout.fragment_movie_list, container, false)
        return _binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //region horizontol recycler
        val llm = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        _binding?.rvMovieHorizontol?.layoutManager = llm
        _binding?.rvMovieHorizontol?.adapter = mAdapter
        mPaginationHandler =
            object :
                PaginationHandler(llm, Constants.MOVIE_LIST_THRESHOLD) {
                override fun onLoadMore(page: Int, totalItemsCount: Int) {
                    if (totalItemsCount < mCountTotal) {
                        mPage = page
                        mviewModel.getMovieList(mPage)
                    }
                }
            }
        _binding?.rvMovieHorizontol?.addOnScrollListener(mPaginationHandler)
        //endregion

        //region gridLayout
        val glm = GridLayoutManager(requireContext(), 3)
        _binding?.rvMovieVertical?.layoutManager = glm
        _binding?.rvMovieVertical?.adapter = mAdapter
        // Pagination Listener
        mPaginationHandlerMulti = object : PaginationHandlerMulti(glm) {
            override fun onLoadMore(page: Int, totalItemsCount: Int, view: RecyclerView?) {
                if (totalItemsCount < mCountTotal) {
                    mPage = page
                    mviewModel.getMovieList(mPage)
                }
            }
        }
        _binding?.rvMovieVertical?.addOnScrollListener(mPaginationHandler)
        //endregion
        mviewModel.getMovieList(mPage)
        observeData()
    }
    //endregion

    //region viewActor Methods
    override fun getMovieDetails(itemData: MovieListResponse.Result) {
        val bundle =
            bundleOf(
                Constants.KEY_MOVIE_ID to itemData.id
            )
        val movieDetailFragment = MovieDetailFragment()
        movieDetailFragment.arguments = bundle
        parentFragmentManager.beginTransaction()
            .replace(R.id.fl_landing_container, movieDetailFragment)
            .addToBackStack(movieDetailFragment.javaClass.simpleName).commit()
    }
    //endregion

    fun observeData() {
        mviewModel.movieListResponse.observe(viewLifecycleOwner, {
            //update total count

            mCountTotal = it.totalResults

            it.results.let { list ->
                if (list.isNotEmpty()) {
                    //add data to alert list
                    mMovieList.addAll(list)
                    //update list
                    mAdapter.updateList(mMovieList)
                    if (mPage.isAddLoading(mCountTotal)) {
                        mAdapter.addLoading()
                    }
                }
            }

        })

    }


}