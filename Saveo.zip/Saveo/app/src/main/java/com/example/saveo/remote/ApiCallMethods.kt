package com.example.saveo.remote

import com.example.saveo.data.response.MovieDetailResponse
import com.example.saveo.data.response.MovieListResponse
import retrofit2.Response
import retrofit2.http.*

/**
 * @AUTHOR Naimish Gupta
 * @date 05/01/2022
 */
interface ApiCallMethods {

    @GET("movie/popular")
   suspend fun getMovieList(
        @Query("api_key") key:String,
        @Query("page") page:Int,
    ):Response<MovieListResponse>

   @GET("movie/{movie_id}")
   suspend fun getMovieDetails(
       @Path("movie_id") movie_Id:Int,
       @Query("api_key") key:String
   ):Response<MovieDetailResponse>
}