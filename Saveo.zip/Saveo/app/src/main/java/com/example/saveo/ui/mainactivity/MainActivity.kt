package com.example.saveo.ui.mainactivity

import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.example.saveo.R
import com.example.saveo.base.BaseActivity
import com.example.saveo.base.FragmentNavigationBuilder
import com.example.saveo.databinding.ActivityMainBinding
import com.example.saveo.ui.movielist.MovieListFragment

/**
 * @AUTHOR Naimish Gupta
 * @date 05/01/2022
 */
class MainActivity : BaseActivity() {
    //region variable
    private var _binding: ActivityMainBinding? = null

    //endregion
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //dataBinding
        _binding = DataBindingUtil.setContentView(this, R.layout.activity_main)


        executeNavigation(
            FragmentNavigationBuilder(MovieListFragment())
                .container(R.id.fl_landing_container)
                .isAddFragment(false)
                .isBackStack(false)
                .bundle(null)
                .build()
        )
    }
}