package com.example.saveo.ui.movielist

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.saveo.data.response.MovieListResponse
import com.example.saveo.remote.ApiCallMethods
import com.example.saveo.utility.Constants
import kotlinx.coroutines.*
import java.lang.ref.WeakReference

/**
 * @AUTHOR Naimish Gupta
 * @date 05/01/2022
 */
class MovieListViewModel(val apiCallMethods: ApiCallMethods) : ViewModel() {

    //region variables
    val errorMessage = MutableLiveData<String>()
    var job: Job? = null
    private lateinit var mViewActor: WeakReference<MovieListViewActor>
    val movieListResponse = MutableLiveData<MovieListResponse>()
    val exceptionHandler = CoroutineExceptionHandler { _, throwable ->
        onError("Exception handled: ${throwable.localizedMessage}")
    }
    //endregion

    //region movieList Api
    fun getMovieList(page: Int) {
        job = CoroutineScope(Dispatchers.IO + exceptionHandler).launch {
            val response = apiCallMethods.getMovieList(key = Constants.API_KEY, page = page)
            withContext(Dispatchers.Main) {
                if (response.isSuccessful) {
                    movieListResponse.postValue(response.body())
                } else {
                    onError("Error : ${response.message()} ")
                }
            }
        }
    }
    //endregion

    //region setting viewActor
    fun setViewActor(viewActor: MovieListViewActor) {
        this.mViewActor = WeakReference(viewActor)
    }

    fun getViewActor(): MovieListViewActor {
        return mViewActor.get()!!
    }

    //endregion
    private fun onError(message: String) {
        errorMessage.value = message
    }

    //region binding variable
    fun onPosterClick(itemData: MovieListResponse.Result) {
        getViewActor().getMovieDetails(itemData)
    }
    //endregion
}