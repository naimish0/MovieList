package com.example.saveo.utility

/**
 * @AUTHOR Naimish Gupta
 * @date 05/01/2022
 */

import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule

/** Ensures that Glide's generated API is created for the Gallery sample.  */
@GlideModule
class GlideAppModule : AppGlideModule()// Intentionally empty.