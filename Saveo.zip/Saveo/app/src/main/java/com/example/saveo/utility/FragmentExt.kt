package com.example.saveo.utility

/**
 * @AUTHOR Naimish Gupta
 * @DATE   05/01/2022
 */
import androidx.fragment.app.Fragment
import com.example.saveo.base.SaveoApplication
import com.example.saveo.base.ViewModelFactory
import com.example.saveo.ui.movielist.MovieListViewActor

fun Fragment.getViewModelFactory(): ViewModelFactory {
    val repository = SaveoApplication.apiCallMethods
    return ViewModelFactory(repository)
}
