package com.example.saveo.ui.movielist

import com.example.saveo.data.response.MovieListResponse
/**
 * @AUTHOR Naimish Gupta
 * @date 05/01/2022
 */
interface MovieListViewActor {

    /**
     * movie Details Method
     */
    fun getMovieDetails(itemData:MovieListResponse.Result)
}