package com.example.saveo.utility
/**
 * @AUTHOR Naimish Gupta
 * @date 05/01/2022
 */
object Constants {
    const val BASE_URL="https://api.themoviedb.org/3/"
    const val API_KEY="b3606e0fcdd9ac3fd7998f0229289840"
    const val IMAGE_PREFIX="https://image.tmdb.org/t/p/original"
    const val MOVIE_LIST_THRESHOLD=5
    const val KEY_MOVIE_ID="movieId"
}